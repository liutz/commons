package com.xiaomi.miadsdkdemo;

import com.miui.zeus.logger.MLog;

import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.facebook.ads.AdSettings;
import com.xiaomi.miglobaladsdk.instream.InstreamVideoAdCallback;
import com.xiaomi.miglobaladsdk.instream.InstreamVideoAdManager;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;
import com.xiaomi.miglobaladsdk.report.AdReportHelper;

public class InstreamVideoAdFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "InstreamVideoAdFragment";

    private static final String PLACE_ID = "1.305.10.1";
    private FrameLayout mAdViewContainer;
    private EditText mEtId;
    private InstreamVideoAdManager mManager;
    private Context mContext;
    private String mFailedMessage;
    private boolean mHasLoadFailed;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getContext();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_instream, container, false);
        root.findViewById(R.id.is_load_ad_btn).setOnClickListener(this);
        root.findViewById(R.id.is_show_ad_btn).setOnClickListener(this);
        root.findViewById(R.id.is_add_btn).setOnClickListener(this);
        // 用于add贴片广告的container
        mAdViewContainer = (FrameLayout) root.findViewById(R.id.is_container);
        mEtId = root.findViewById(R.id.is_et_id);

        // 根据实际调整下面的代码，这里主要用于设置贴片广告的长和宽
        WindowManager wm = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
        Point size = new Point();
        assert wm != null;
        wm.getDefaultDisplay().getSize(size);
        mAdViewContainer.getLayoutParams().width = size.x;
        mAdViewContainer.getLayoutParams().height = size.x * 9 / 16;

        mManager = new InstreamVideoAdManager(mContext, PLACE_ID);
        mManager.setInstreamAdCallback(new InstreamVideoAdCallback() {
            @Override
            public void onAdVideoComplete(INativeAd ad) {
                // Instream Video View Complete - the video has been played to the end.
                // You can use this event to continue your video playing
                // 贴片广告播放完成或者点击了skip ad后回调
                // 根据需要释放
                mManager.destroyAd();
                Toast.makeText(mContext, "onAdVideoComplete", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adLoaded() {
                // 贴片广告加载成功后回调，调用showAd()就能播放广告了
                MLog.d(TAG, "adType" + mManager.getAdType());
                Toast.makeText(mContext, "ad is ready for show", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adFailedToLoad(int code) {
                mHasLoadFailed = true;
                mFailedMessage = "ad load failed, error code is " + code;
                Toast.makeText(mContext, mFailedMessage, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adImpression(INativeAd nativeAd) {
                Toast.makeText(mContext, "adImpression", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adClicked(INativeAd nativeAd) {
                Toast.makeText(mContext, "adClicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                MLog.d(TAG, "AdDisliked nativeAd");
            }
        });
        // addTestDevice
        //如果使用默认的 Google Android 模拟器（Genymotion 和物理设备不需要执行此步骤），需要在加载测试广告前添加以下代码行：
        //logcat过滤addTestDevice即可找到
        AdSettings.addTestDevice("TestDevice");
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // 媒体方自定义打点时使用此方法, key和value需要和服务端协商好在传入
        AdReportHelper.reportPV(PLACE_ID);
    }

    @Override
    public void onDestroy() {
        mManager.destroyAd();
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.is_load_ad_btn:
                mHasLoadFailed = false;
                // 这种load方式将以container的大小显示贴片广告
                mManager.loadAd(mAdViewContainer);
                // 这种load方式将以自定义大小显示贴片广告
                // mManager.loadAd(mAdViewContainer, width, height);
                Toast.makeText(mContext, "loading ad", Toast.LENGTH_SHORT).show();
                break;
            case R.id.is_show_ad_btn:
                if (mManager.isReady()) {
                    mManager.showAd();
                } else {
                    Toast.makeText(mContext, mHasLoadFailed ? mFailedMessage : "ad is not ready, try later",
                            Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.is_add_btn:
                String id = mEtId.getText().toString().trim();
                MLog.d(TAG, "ID:" + id);
                AdSettings.addTestDevice(id);
                break;
                default:
                    MLog.d(TAG, "No match operation case");
                    break;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mManager.onResume();
    }
}
