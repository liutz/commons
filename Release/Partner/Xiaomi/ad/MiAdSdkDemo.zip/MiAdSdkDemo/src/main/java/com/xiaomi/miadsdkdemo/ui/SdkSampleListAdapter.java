package com.xiaomi.miadsdkdemo.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.xiaomi.miadsdkdemo.R;

import java.util.ArrayList;

/**
 * Created by xiezhilin on 17-4-14.
 */
public class SdkSampleListAdapter extends ArrayAdapter<SdkSampleBean> {

    static class ViewHolder {
        TextView description;
        TextView adUnitId;
    }

    private final LayoutInflater mLayoutInflater;

    SdkSampleListAdapter(final Context context) {
        super(context, 0, new ArrayList<SdkSampleBean>());
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public View getView(final int position, final View convertView, final ViewGroup parent) {
        final View view;
        final ViewHolder viewHolder;

        if (convertView == null) {
            view = mLayoutInflater.inflate(R.layout.sample_list_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.description = (TextView) view.findViewById(R.id.description);
            viewHolder.adUnitId = (TextView) view.findViewById(R.id.ad_unit_id);
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }

        view.setTag(viewHolder);
        final SdkSampleBean sampleAdUnit = getItem(position);
        viewHolder.description.setText(sampleAdUnit.getDescription());
        viewHolder.adUnitId.setText("adid：" + sampleAdUnit.getAdId());

        return view;
    }

}
