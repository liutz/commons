package com.xiaomi.miadsdkdemo.base;

import android.app.Application;
import android.text.TextUtils;

import com.cmcm.orion.adsdk.OrionSdk;
import com.facebook.ads.AudienceNetworkAds;
import com.mintegral.msdk.MIntegralSDK;
import com.mintegral.msdk.out.MIntegralSDKFactory;
import com.miui.zeus.columbus.ad.AdGlobalSdk;
import com.squareup.leakcanary.LeakCanary;
import com.xiaomi.ad.mediationconfig.MediationConfigProxySdk;
import com.xiaomi.analytics.Analytics;
import com.xiaomi.miadsdkdemo.BuildConfig;
import com.xiaomi.miadsdkdemo.util.FileUtils;
import com.xiaomi.miglobaladsdk.Const;
import com.xiaomi.miglobaladsdk.MiAdManager;

import java.util.Map;

/**
 * Created by zhangtao on 17-4-12.
 */

public class MyApplication extends Application {
    private static final String TAG = "MyApplication";

    @Override
    public void onCreate() {
        super.onCreate();
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis.
            // You should not init your app in this process.
            return;
        }
        LeakCanary.install(this);
        initSDK();
    }

    private void initSDK() {
        //Debug包下开启Debug模式，开始打印log
        if (BuildConfig.DEBUG) {
            MiAdManager.enableDebug();
        }
        Analytics.getInstance(getApplicationContext()).setDebugOn(true);
        String defaultConfigStr = FileUtils.readStringFromAsset(this, "default-config.txt");
        if (!TextUtils.isEmpty(defaultConfigStr)) {
            //set default config before application init
            MiAdManager.setDefaultConfig(defaultConfigStr, true);// true使用本地配置(assets目录下),上线前务必改为false
        }
        // Zeus-Columbus init
        AdGlobalSdk.initialize(getApplicationContext(), "MISDK_DEMO", "ee60917ed59044e5dbf7f71fa366acd3");
        // 默认打开开发者模式，使用测试环境
        AdGlobalSdk.setDebugOn(true);
        AdGlobalSdk.setStaging(true);

        // Initialize the Audience Network SDK
        AudienceNetworkAds.initialize(this);

        MiAdManager.applicationInit(this, "10000", "miglobaladsdk_test", true);

        OrionSdk.setTestDataModel(true);
        OrionSdk.applicationInit(this, "128");
        MediationConfigProxySdk.setStaging();
    }
}
