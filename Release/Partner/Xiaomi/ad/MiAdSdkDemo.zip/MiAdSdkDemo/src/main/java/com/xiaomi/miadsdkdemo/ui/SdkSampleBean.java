package com.xiaomi.miadsdkdemo.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

/**
 * Created by xiezhilin on 17-4-14.
 */
public class SdkSampleBean {

    public static final String AD_ID = "adId";
    public static final String DESCRIPTION = "description";
    public static final String AD_TYPE = "adType";

    private final String mAdid;
    private final SdkSampleListFragmentItem.SdkAdType mAdType;
    private final String mDescription;

    private SdkSampleBean(final Builder builder) {
        mAdid = builder.mAdId;
        mAdType = builder.mAdType;
        mDescription = builder.mDescription;
    }

    Class<? extends Fragment> getFragmentClass() {
        return mAdType.getFragmentClass();
    }

    public String getAdId() {
        return mAdid;
    }

    public String getAdType(){
        return mAdType.name();
    }

    public String getDescription() {
        return mDescription;
    }

    Bundle toBundle() {
        final Bundle bundle = new Bundle();
        bundle.putString(AD_ID, mAdid);
        bundle.putString(DESCRIPTION, mDescription);
        bundle.putSerializable(AD_TYPE, mAdType);

        return bundle;
    }

    public static SdkSampleBean fromBundle(final Bundle bundle) {
        final String posid = bundle.getString(AD_ID);
        final SdkSampleListFragmentItem.SdkAdType adType = (SdkSampleListFragmentItem.SdkAdType) bundle.getSerializable(AD_TYPE);
        final String description = bundle.getString(DESCRIPTION);
        final Builder builder = new SdkSampleBean.Builder(adType);
        builder.adid(posid);
        builder.description(description);

        return builder.build();
    }

    static class Builder {
        private String mAdId;
        private SdkSampleListFragmentItem.SdkAdType mAdType;
        private String mDescription;

        Builder(final SdkSampleListFragmentItem.SdkAdType adType) {
            mAdType = adType;
        }

        Builder adid(final String posid) {
            mAdId = posid;
            return this;
        }

        Builder description(final String description) {
            mDescription = description;
            return this;
        }

        SdkSampleBean build() {
            return new SdkSampleBean(this);
        }
    }

}
