package com.xiaomi.miadsdkdemo.util;

/**
 * Created by xzl on 17-4-17.
 */

public class CommonUtils {

    public static int range(int n, int min, int max) {
        if (n <= min) {
            return min;
        } else if (n >= max) {
            return max;
        }
        return n;
    }

}
