package com.xiaomi.miadsdkdemo;

import com.miui.zeus.logger.MLog;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import com.xiaomi.miglobaladsdk.bannerad.BannerAdCallback;
import com.xiaomi.miglobaladsdk.bannerad.BannerAdManager;
import com.xiaomi.miglobaladsdk.bannerad.BannerAdSize;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;
import com.xiaomi.miglobaladsdk.report.AdReportHelper;

/**
 * Copyright (C) 2013, Xiaomi Inc. All rights reserved.
 */

public class BannerAdFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "BannerAdFragment";
    private static final String POSITION_ID = "1.305.2.1";
    private Context mContext;
    private View mRoot;
    private RelativeLayout mAdViewContainer;
    private BannerAdManager mBannerAdManager;
    private EditText mWidth, mHeight;
    private List<BannerAdSize> mBannerSizeList;
    private CheckBox mCheckBox;
    private boolean isLoaded = false;
    private boolean isEnableWebView = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity().getApplicationContext();
        mBannerSizeList = new ArrayList<>();
        mBannerSizeList.add(new BannerAdSize(320, 50));
        mBannerAdManager = new BannerAdManager(mContext, POSITION_ID);
        mBannerAdManager.setIsWebViewBannerSupported(false);
        mBannerAdManager.setBannerAdCallback(new BannerAdCallback() {
            @Override
            public void adLoaded(int width, int height) {
                //浏览器专用
                isLoaded = true;
                Log.d(TAG, "width" + width + "height" + height);
            }

            @Override
            public void adLoaded() {
                isLoaded = true;
                Toast.makeText(mContext, "onLoaderLoaded", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adFailedToLoad(int errorCode) {
                Toast.makeText(mContext, "onLoaderFailed errorCode:" + errorCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adImpression(INativeAd nativeAd) {
                Toast.makeText(mContext, "adImpression bannerAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adClicked(INativeAd nativeAd) {
                Toast.makeText(mContext, "adClicked bannerAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                MLog.d(TAG, "AdDisliked nativeAd");
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mRoot = layoutInflater.inflate(R.layout.fragment_bannerad_layout, container, false);
        mRoot.findViewById(R.id.btn_load_bannerad).setOnClickListener(this);
        mRoot.findViewById(R.id.btn_show_bannerad).setOnClickListener(this);
        mRoot.findViewById(R.id.btn_add_size).setOnClickListener(this);
        mRoot.findViewById(R.id.btn_clear_size).setOnClickListener(this);
        mAdViewContainer = mRoot.findViewById(R.id.bannerad_container);
        mWidth = mRoot.findViewById(R.id.width);
        mHeight = mRoot.findViewById(R.id.height);
        mCheckBox = mRoot.findViewById(R.id.checkbox);

        mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    isEnableWebView = false;
                } else {
                    isEnableWebView = true;
                }
            }
        });
        return mRoot;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // 媒体方自定义打点时使用此方法, key和value需要和服务端协商好在传入
        AdReportHelper.reportPV(POSITION_ID);
    }

    @Override
    public void onDestroy() {
        mBannerAdManager.destroyAd();
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_load_bannerad:
                loadAd();
                Toast.makeText(mContext, "Loading ads and please wait!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_show_bannerad:
                showAd();
                break;
            case R.id.btn_add_size:
                addSize();
                break;
            case R.id.btn_clear_size:
                clearSize();
                break;
            default:
                break;
        }
    }
    /**The standard admob banner sizes
     * Size in dp (WxH)     Description          Availability                   MiAdSize constant
     320x50                Banner               Phones and Tablets                BANNER
     320x100               Large Banner         Phones and Tablets                LARGE_BANNER
     300x250               IAB Medium Rectangle Phones and Tablets                MEDIUM_RECTANGLE
     468x60                IAB Full-Size Banner Tablets                           FULL_BANNER
     728x90                IAB Leaderboard      Tablets                           LEADERBOARD
     Screen width x 32|50|90  Smart Banner      Phones and Tablets                SMART_BANNER
     */
    /**
     * The standard facebook banner sizes
     * The width if flexible with a minimum of 320px, and only the height is defined.
     * 320x50            Standard Banner   Phones                                   BANNER_HEIGHT_50
     * 320x90            Larger Banner     tablets and larger devices               BANNER_HEIGHT_90
     * 300x250           Medium Rectangle  scrollable feeds or end-of-level screens RECTANGLE_HEIGHT_250
     */
    private void loadAd() {
        mAdViewContainer.removeAllViews();
        if (mBannerAdManager != null) {
            // U must set banner size by setBannerSize or setBannerSizeList
            mBannerAdManager.setIsWebViewBannerSupported(isEnableWebView);
            mBannerAdManager.setBannerSizeList(mBannerSizeList);
            mBannerAdManager.loadAd();
        }
    }

    private void addSize() {
        if (mWidth.getText().toString().equals("")) {
            Toast.makeText(getContext(), "Width can not be null", Toast.LENGTH_SHORT).show();
            return;
        }

        if (mHeight.getText().toString().equals("")) {
            Toast.makeText(getContext(), "Height can not be null", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            int width = Integer.parseInt(mWidth.getText().toString());
            int height = Integer.parseInt(mHeight.getText().toString());
            MLog.d(TAG, "width:" + width + "height:" + height);
            mBannerSizeList.add(new BannerAdSize(width, height));
        } catch (Exception e) {
            MLog.e(TAG, "ParseInt exception", e);
        }

    }

    private void clearSize() {
        mBannerSizeList.clear();
    }

    private void showAd() {
        if (mBannerAdManager.isReady() && isLoaded) {
            mBannerAdManager.showAd(mAdViewContainer);
        } else {
            Toast.makeText(mContext, "Please click LOAD to load!", Toast.LENGTH_SHORT).show();
        }
    }

}
