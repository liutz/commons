package com.xiaomi.miadsdkdemo.ui;

import com.miui.zeus.logger.MLog;

import android.content.Context;
import android.support.v4.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import com.xiaomi.miadsdkdemo.R;

import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.BANNER;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.CUSTOMAD;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.INSTREAM;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.INTERSTITIAL;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.NATIVE;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.PROCESS;
import static com.xiaomi.miadsdkdemo.ui.SdkSampleListFragmentItem.SdkAdType.REWARDEDVIDEO;

/**
 * Created by xiezhilin on 17-4-14.
 * 在SdkAdType增加广告类型的测试fragment,在getDefaultItem中增加fragment的item
 */
public class SdkSampleListFragmentItem {
    private static final String TAG = "SdkSampleListFragmentItem";


    public enum SdkAdType {
        NATIVE("NativeAdFragment"),
        // SPLASH("SplashAdFragment"),
        INTERSTITIAL("InterstitialAdFragment"),
        // FEEDLIST("FeedListAdFragment"),
        PROCESS("StartProcessFragment"),
        INSTREAM("InstreamVideoAdFragment"),
        REWARDEDVIDEO("RewardedVideoAdFragment"),
        BANNER("BannerAdFragment"),
        CUSTOMAD("CustomAdFragment");

        private Class<? extends Fragment> fragmentClass;

        SdkAdType(final String fragmentClass) {
            try {
                this.fragmentClass = (Class<? extends Fragment>) Class
                        .forName("com.xiaomi.miadsdkdemo." + fragmentClass);
            } catch (ClassNotFoundException e) {
                MLog.e(TAG, "stackError", e);
            }
        }

        public Class<? extends Fragment> getFragmentClass() {
            return fragmentClass;
        }
    }

    private Context mContext;

    SdkSampleListFragmentItem(final Context context) {
        mContext = context.getApplicationContext();
    }

    List<SdkSampleBean> getDefaultItem() {
        final List<SdkSampleBean> adUnitList = new ArrayList<SdkSampleBean>();
        adUnitList.add(
                new SdkSampleBean
                        .Builder(NATIVE)
                        .adid(mContext.getString(R.string.id_native))
                        .description("Native Test")
                        .build());
//        adUnitList.add(
//                new SdkSampleBean
//                        .Builder(FEEDLIST)
//                        .adid("10010")
//                        .description("FeedList Test")
//                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(INTERSTITIAL)
                        .adid("10011")
                        .description("Interstitial Test")
                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(PROCESS)
                        .adid("10012")
                        .description("Process Test")
                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(INSTREAM)
                        .adid("10013")
                        .description("Instream Video Test")
                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(REWARDEDVIDEO)
                        .adid("10014")
                        .description("RewardedVideo Test")
                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(BANNER)
                        .adid("10015")
                        .description("Banner Test")
                        .build());
        adUnitList.add(
                new SdkSampleBean
                        .Builder(CUSTOMAD)
                        .adid("10016")
                        .description("CustomAD Test")
                        .build());
        return adUnitList;
    }
}
