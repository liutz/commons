package com.xiaomi.miadsdkdemo;

import com.miui.zeus.logger.MLog;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.xiaomi.miadsdkdemo.ui.SdkSampleBean;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;
import com.xiaomi.miglobaladsdk.report.AdReportHelper;
import com.xiaomi.miglobaladsdk.rewardedvideoad.RewardedVideoAdCallback;
import com.xiaomi.miglobaladsdk.rewardedvideoad.RewardedVideoAdManager;


public class RewardedVideoAdFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "RewardedVideoAdFragment";

    private SdkSampleBean mSampleBean;
    private static final String POSITION_ID = "1.305.1.3";
    private Context mContext;
    private View mContentView;

    private RewardedVideoAdManager mRewardedVideoAdManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity();
        mRewardedVideoAdManager = new RewardedVideoAdManager(mContext, POSITION_ID);
        mRewardedVideoAdManager.setRewardedVideoAdCallback(new RewardedVideoAdCallback() {
            @Override
            public void adLoaded() {
                Toast.makeText(mContext, "onLoaderLoaded", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adFailedToLoad(int errorCode) {
                Toast.makeText(mContext, "onLoaderFailed errorCode:" + errorCode, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adImpression(INativeAd nativeAd) {
                Toast.makeText(mContext, "adImpression rewardedVideoAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adClicked(INativeAd nativeAd) {
                Toast.makeText(mContext, "adClicked rewardedVideoAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                MLog.d(TAG, "AdDisliked nativeAd");
            }

            @Override
            public void onAdStarted() {
                Toast.makeText(mContext, "adStarted rewardedVideoAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdCompleted() {
                Toast.makeText(mContext, "adCompleted rewardedVideoAd", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdRewarded() {
                Toast.makeText(mContext, "You are rewarded!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdDismissed() {
                Toast.makeText(getActivity(), "adDismissed rewardedVideoAd", Toast.LENGTH_SHORT).show();
            }

        });
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        mContentView = inflater.inflate(R.layout.fragment_rewardedvideoad_layout, container, false);
        mSampleBean = SdkSampleBean.fromBundle(getArguments());

        mContentView.findViewById(R.id.btn_loadRewardedVideo).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_preLoadRewardedVideo).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_showRewardedVideo).setOnClickListener(this);
        ((TextView) mContentView.findViewById(R.id.description)).setText(mSampleBean.getDescription());

        return mContentView;
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_loadRewardedVideo:
                loadAd();
                Toast.makeText(mContext, "Loading ads and please wait!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_preLoadRewardedVideo:
                preLoadAd();
                Toast.makeText(mContext, "PreLoading ad and please wait!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_showRewardedVideo:
                showAd();
                break;
            default:
                break;
        }
    }

    private void loadAd() {
        if (mRewardedVideoAdManager != null) {
            mRewardedVideoAdManager.loadAd();
        }
    }

    private void preLoadAd() {
        if (mRewardedVideoAdManager != null) {
            mRewardedVideoAdManager.preLoadAd();
        }
    }

    private void showAd() {
        AdReportHelper.reportPV(POSITION_ID);
        if (mRewardedVideoAdManager.isReady()) {
            mRewardedVideoAdManager.showAd();
        } else {
            Toast.makeText(mContext, "Please click LOAD or PRELOAD to load!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mRewardedVideoAdManager.destroyAd();
    }
}