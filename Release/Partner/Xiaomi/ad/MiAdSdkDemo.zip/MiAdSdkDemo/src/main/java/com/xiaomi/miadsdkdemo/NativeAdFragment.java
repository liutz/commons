package com.xiaomi.miadsdkdemo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.miui.zeus.columbus.ad.nativead.NativeAd;
import com.miui.zeus.logger.MLog;
import com.xiaomi.miadsdkdemo.ui.SdkSampleBean;
import com.xiaomi.miadsdkdemo.util.AdViewHelper;
import com.xiaomi.miglobaladsdk.FeedbackConst;
import com.xiaomi.miglobaladsdk.adapter.admob.AdmobAdRenderer;
import com.xiaomi.miglobaladsdk.adapter.columbus.ColumbusAdRenderer;
import com.xiaomi.miglobaladsdk.adapter.facebook.FacebookAdRenderer;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;
import com.xiaomi.miglobaladsdk.nativead.api.LoadConfigBean;
import com.xiaomi.miglobaladsdk.nativead.api.NativeAdManager;
import com.xiaomi.miglobaladsdk.report.AdReportHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * native 大小卡
 * 123=fb:1501691280131268_1501691433464586
 * 456=fb:1501691280131268_1596601087306953
 * 804715676350691_804734249682167
 */
public class NativeAdFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = "NativeAdFragment";
    private static final int REQUEST_AD_SIZE = 4;
    private SdkSampleBean sampleBean;
    private String mPositionId = "1.305.1.1";
    private Context mContext;
    private View mContentView;
    private FrameLayout nativeAdContainer;
    private ListView mAdListView;
    private INativeAd mNativeAd;

    private NativeAdManager mNativeAdManager;
    private int dislikeCode;
    private List<INativeAd> mNativeAds;
    private List mViewList = new ArrayList();

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity().getApplicationContext();
        mNativeAdManager = new NativeAdManager(mContext, mPositionId);
        registerAdRenderer();// 务必在loadAd前registerAdRenderer
        String extraInfo = mNativeAdManager.getExtraInfo(mPositionId);
        if (!TextUtils.isEmpty(extraInfo)) {
            MLog.i(TAG, extraInfo);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        mContentView = inflater.inflate(R.layout.fragment_nativead_layout, container, false);
        sampleBean = SdkSampleBean.fromBundle(getArguments());

        nativeAdContainer = mContentView.findViewById(R.id.big_ad_container);
        mContentView.findViewById(R.id.btn_load).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_loadAds).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_showListAd).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_show).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_dislike).setOnClickListener(this);
        mContentView.findViewById(R.id.btn_reportPv).setOnClickListener(this);

        ((TextView) mContentView.findViewById(R.id.description)).setText(sampleBean.getDescription());

        // TODO: 17-4-28 to report pv
        // AdReportHelper.reportPV(mPositionId);
        // 媒体方自定义打点时使用此方法, key和value需要和服务端协商好再传入
        AdReportHelper.reportCustomPV(mPositionId, "customKey", "customValue");
        mNativeAdManager.setLoadConfig(new LoadConfigBean.Builder()
                .setNativeAdOptionsAB(LoadConfigBean.NativeAdOptions.ADCHOICES_BOTTOM_LEFT)
                .build());
        return mContentView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_load:
                loadAd();
                break;
            case R.id.btn_loadAds:
                loadAds();
                break;
            case R.id.btn_showListAd:
                showAdList();
                break;
            case R.id.btn_show:
                showAd();
                break;
            case R.id.columbus_native_dislike:
                dislikeAd(mNativeAd);
                break;
            case R.id.btn_reportPv:
                AdReportHelper.reportPV(mPositionId);
                break;
            default:
                break;
        }
    }

    @Override
    public void onDestroy() {
        if (mNativeAd != null) {
            mNativeAd.unregisterView();
        }
        if (mNativeAds != null) {
            for (INativeAd iNative : mNativeAds) {
                iNative.unregisterView();
            }
        }
        if (mAdListView != null) {
            mAdListView.setAdapter(null);
        }
        mNativeAdManager.destroyAd();
        super.onDestroy();
    }

    private void loadAd() {
        if (mNativeAdManager != null) {
            mNativeAdManager.setLoadConfig(new LoadConfigBean.Builder()
                    .setNativeAdOptionsAB(LoadConfigBean.NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build());
            mNativeAdManager.setNativeAdManagerListener(new NativeAdManager.NativeAdManagerListener() {

                @Override
                public void adLoaded() {
                    Toast.makeText(mContext, "onLoaderLoaded", Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "adLoaded");
                }

                @Override
                public void adFailedToLoad(int code) {
                    Toast.makeText(mContext, "onLoaderFailed errorCode:" + code, Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "OnLoaderFailed errorCode: " + code);
                }

                @Override
                public void adImpression(INativeAd nativeAd) {
                    Toast.makeText(mContext, "adImpression nativeAd" + nativeAd.getAdTypeName(), Toast.LENGTH_SHORT)
                            .show();
                }

                @Override
                public void adClicked(INativeAd nativeAd) {
                    Toast.makeText(mContext, "adClicked nativeAd" + nativeAd.getAdTitle(), Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "AdClicked nativeAd: " + nativeAd.getAdTitle());
                }

                @Override
                public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                    nativeAd.unregisterView();
                    nativeAdContainer.removeAllViews();
                    mNativeAd = null;
                    MLog.d(TAG, "AdDisliked nativeAd, dislikeCode: " + dislikeCode);
                }
            });
            mNativeAdManager.loadAd("com.android.picks,com.xiaomi.games");
        }
    }

    private void registerAdRenderer() {
        final FacebookAdRenderer facebookAdRenderer = new FacebookAdRenderer(
                new FacebookAdRenderer.FacebookViewBinder.Builder(R.layout.facebook_native_ad_layout)
                        .nativeAdLayoutId(R.id.native_ad_layout)
                        .titleId(R.id.fb_native_title, false)
                        .textId(R.id.fb_native_text, false)
                        .mediaId(R.id.fb_native_main_media)
                        .iconId(R.id.fb_native_ad_icon)
                        .callToActionId(R.id.fb_native_cta, false)
                        .adChoicesContainerId(R.id.fb_ad_choices_container)
                        .dislikeId(R.id.fb_native_dislike)
                        .build()
        );
        final AdmobAdRenderer admobAdRenderer = new AdmobAdRenderer(
                new AdmobAdRenderer.AdmobViewBinder.Builder(R.layout.admob_native_ad_layout)
                        .titleId(R.id.unified_title)
                        .textId(R.id.unified_body)
                        .mediaId(R.id.unified_media_view)
                        .iconId(R.id.unified_icon)
                        .callToActionId(R.id.unified_action_btn)
                        .dislikeId(R.id.unified_dislike)
                        .build());
        final ColumbusAdRenderer columbusAdRenderer = new ColumbusAdRenderer(
                new ColumbusAdRenderer.ColumbusViewBinder.Builder(R.layout.columbus_native_ad_layout)
                        .titleId(R.id.columbus_native_title)
                        .textId(R.id.columbus_native_text)
                        .imageId(R.id.columbus_native_main_image)
                        .iconId(R.id.columbus_native_icon_image)
                        .callToActionId(R.id.columbus_native_cta)
                        .adChoicesContainerId(R.id.columbus_ad_choices_container)
                        .dislikeId(R.id.columbus_native_dislike, false)// 不使用默认弹窗
                        .build()
        );
        mNativeAdManager.registerAdRenderer(admobAdRenderer);
        mNativeAdManager.registerAdRenderer(facebookAdRenderer);
        mNativeAdManager.registerAdRenderer(columbusAdRenderer);
    }

    private void loadAds() {
        if (mNativeAdManager != null) {
            mNativeAdManager.setLoadConfig(new LoadConfigBean.Builder()
                    .setNativeAdSize(REQUEST_AD_SIZE)
                    .build());
            mNativeAdManager.setNativeAdManagerListener(new NativeAdManager.NativeAdListManagerListener() {
                @Override
                public void adLoaded(int adSize) {
                    Toast.makeText(mContext, "onAdLoaded: " + adSize, Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "adLoaded: " + adSize);
                }

                @Override
                public void adLoaded() {
                    Toast.makeText(mContext, "onLoaderLoaded", Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "adLoaded");
                }

                @Override
                public void adFailedToLoad(int code) {
                    Toast.makeText(mContext, "onLoaderFailed errorCode:" + code, Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "OnLoaderFailed errorCode: " + code);
                }

                @Override
                public void adImpression(INativeAd nativeAd) {
                    Toast.makeText(mContext, "adImpression nativeAd" + nativeAd.getAdTypeName(), Toast.LENGTH_SHORT)
                            .show();
                }

                @Override
                public void adClicked(INativeAd nativeAd) {
                    Toast.makeText(mContext, "adClicked nativeAd" + nativeAd.getAdTitle(), Toast.LENGTH_SHORT).show();
                    MLog.d(TAG, "AdClicked nativeAd: " + nativeAd.getAdTitle());
                }

                @Override
                public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                    nativeAd.unregisterView();
                    nativeAdContainer.removeAllViews();
                    mNativeAd = null;
                    MLog.d(TAG, "AdDisliked nativeAd, dislikeCode: " + dislikeCode);
                }
            });
            mNativeAdManager.loadAd();
        }
    }

    private void preloadAd() {
        if (mNativeAdManager != null) {
            mNativeAdManager.preloadAd();
        }
    }

    private void showAdList() {
        if (mNativeAdManager != null) {
            mNativeAds = mNativeAdManager.getAdList();
            mViewList.clear();
            if (mNativeAds != null && mNativeAds.size() > 0) {
                for (INativeAd iNativeAd : mNativeAds) {
                    MLog.d(TAG, "adTypeName: " + iNativeAd.getAdTypeName());
                    mViewList.add(AdViewHelper.createAdView(mContext, iNativeAd));
                }
            } else {
                Toast.makeText(mContext,
                        "no native mNativeAd loaded!", Toast.LENGTH_SHORT).show();
            }
        }
        mAdListView = new ListView(mContext);
        nativeAdContainer.removeAllViews();
        nativeAdContainer.addView(mAdListView);
        mAdListView.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                if (mViewList != null) {
                    return mViewList.size();
                }
                return 0;
            }

            @Override
            public Object getItem(int position) {
                return mViewList.get(position);
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                return (View) mViewList.get(position);
            }
        });
    }

    private void showAd() {
        if (mNativeAdManager != null) {
            if (mNativeAd != null) {
                // 对上一个展示的广告做处理
                nativeAdContainer.removeAllViews();
                mNativeAd.unregisterView();
            }
            mNativeAd = mNativeAdManager.getAd();
            if (mNativeAd == null) {
                nativeAdContainer.removeAllViews();
                Toast.makeText(mContext,
                        "no native mNativeAd loaded!", Toast.LENGTH_SHORT).show();
                return;
            }

            mNativeAd.setAdOnClickListener(new INativeAd.IAdOnClickListener() {

                @Override
                public void onAdClick(INativeAd nativeAd) {
                    MLog.d(TAG, "ShowAd: onAdClick -- title: " + nativeAd.getAdTitle());
                }
            });
            mNativeAd.setImpressionListener(new INativeAd.ImpressionListener() {
                @Override
                public void onLoggingImpression(INativeAd nativeAd) {
                    MLog.d(TAG, "ShowAd: onLoggingImpression -- title: " + nativeAd.getAdTitle());
                }
            });
            mNativeAd.setOnAdDislikedListener(new INativeAd.IOnAdDislikedListener() {
                @Override
                public void onAdDisliked(INativeAd nativeAd, int dislikeCode) {
                    MLog.d(TAG, "ShowAd: onAdDisliked -- dislikeCode: " + dislikeCode);
                }
            });

            Toast.makeText(mContext,
                    "Ad index is: " + mNativeAd.getAdPriorityIndex(), Toast.LENGTH_SHORT).show();

            //如果只要实现某个类型的广告，需要判断广告类型通过ad.getAdTypeName()
            MLog.d(TAG, "body: " + mNativeAd.getAdBody() + " ,title: " + mNativeAd.getAdTitle() + " ,type: " + mNativeAd
                    .getAdTypeName());
            MLog.d(TAG, "adPackageName: " + mNativeAd.getAdPackageName());

//            View adView = AdViewHelper.createAdView(mContext, mNativeAd);
            View adView = mNativeAd.getAdView(mContext, null);
            // 与前面注册AdRender代码对应，Columbus若使用自定义反馈弹窗需要开发者自行处理：
            if (mNativeAd.getAdObject() instanceof NativeAd) {
                MLog.d(TAG, "columbus dislike setOnClickListener: ");
                adView.findViewById(R.id.columbus_native_dislike).setOnClickListener(this);
            }

            if (adView != null) {
                nativeAdContainer.removeAllViews();
                nativeAdContainer.addView(adView);
            }
        }
    }

    private void dislikeAd(INativeAd nativeAd) {
        if (nativeAd == null) {
            Toast.makeText(mContext, "no native ad showing!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (nativeAd != null) {
            /**
             * 使用默认弹窗时调用
             * nativeAd.dislikeAndReport(mContext);// AdRenderer内部默认处理方式，如注册Render时选择使用默认弹窗则无需重复调用
             */

            /**
             * 如需自定义弹窗，请进行以下操作
             * (1)自定义弹窗，反馈原因及反馈码请严格按照com.xiaomi.miglobaladsdk.FeedbackConst，禁止更改，如需增加请务必协商好再加入
             *      Your code;
             * (2)广告反馈打点调用  ***必须传入正确的广告反馈码***
             *      nativeAd.dislikeAndReport(context, dislikeCode);
             * 自定义弹窗示例:
             */
            showFirstDialog(nativeAd, mContext);
        }
    }

    private void showFirstDialog(final INativeAd nativeAd, final Context context) {
        final String[] reasons = {FeedbackConst.DISLIKE_NOT_INTERESTED, FeedbackConst.DISLIKE_REPETITIVE,
                FeedbackConst.DISLIKE_POOR_QUALITY, FeedbackConst.DIALOG_REPORT_ISSUE, FeedbackConst.DIALOG_CANCEL};
        final AlertDialog.Builder dialogFirst = new AlertDialog.Builder(context);
        dialogFirst.setTitle(FeedbackConst.DIALOG_TITLE)
                .setItems(reasons, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                dislikeCode = FeedbackConst.CODE_NOT_INTERESTED;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                MLog.i(TAG, "dislikeCode: " + dislikeCode);
                                break;
                            case 1:
                                dislikeCode = FeedbackConst.CODE_REPETITIVE;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            case 2:
                                dislikeCode = FeedbackConst.CODE_POOR_QUALITY;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            case 3:
                                showSecondDialog(nativeAd, context);
                                break;
                            case 4:
                                dislikeCode = FeedbackConst.CODE_SKIP;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            default:
                                break;
                        }
                    }
                });
        dialogFirst.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                dislikeCode = FeedbackConst.CODE_SKIP;
                nativeAd.dislikeAndReport(context, dislikeCode);
            }
        });
        dialogFirst.show();
    }

    private void showSecondDialog(final INativeAd nativeAd, final Context context) {
        final String[] reasons = {FeedbackConst.DISLIKE_INAPPROPRIATE_PICTURE, FeedbackConst.DISLIKE_FRAUD_INFO,
                FeedbackConst.DISLIKE_OTHERS, FeedbackConst.DIALOG_CANCEL};
        final AlertDialog.Builder dialogSecond = new AlertDialog.Builder(context);
        dialogSecond.setTitle(FeedbackConst.DIALOG_REPORT_ISSUE)
                .setItems(reasons, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                dislikeCode = FeedbackConst.CODE_INAPPROPRIATE_PICTURE;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            case 1:
                                dislikeCode = FeedbackConst.CODE_FRAUD_INFO;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            case 2:
                                dislikeCode = FeedbackConst.CODE_OTHERS;
                                nativeAd.dislikeAndReport(context, dislikeCode);
                                break;
                            case 3:
                                showFirstDialog(nativeAd, context);
                                break;
                            default:
                                break;
                        }
                    }
                });
        dialogSecond.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                showFirstDialog(nativeAd, context);
            }
        });
        dialogSecond.show();
    }

}