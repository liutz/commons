package com.xiaomi.miadsdkdemo.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;

import com.xiaomi.miadsdkdemo.R;
import com.xiaomi.miglobaladsdk.MiAdManager;

/**
 * Created by xuweiyu on 18-1-9.
 * Email:xuweiyu@xiaomi.com
 */

public class UiProcessActivity extends Activity implements View.OnClickListener {
    private Button mNotOnlyMain;
    private Button mOnlyMain;
    private Context mContext;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getApplicationContext();
        setContentView(R.layout.activity_ui_process);
        mNotOnlyMain = (Button) findViewById(R.id.only_main_process);
        mOnlyMain = (Button) findViewById(R.id.not_only_main_process);
        mNotOnlyMain.setOnClickListener(this);
        mOnlyMain.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.only_main_process:
                MiAdManager.onlyMainProcess();
                MiAdManager.applicationInit(mContext, "10000", "miglobaladsdk_test");
                break;
            case R.id.not_only_main_process:
                MiAdManager.disenableOnlyMainProcess();
                MiAdManager.applicationInit(mContext, "10000", "miglobaladsdk_test");
                break;
        }
    }
}
