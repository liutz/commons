package com.xiaomi.miadsdkdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.xiaomi.miadsdkdemo.ui.UiProcessActivity;

/**
 * Created by xuweiyu on 18-1-9.
 * Email:xuweiyu@xiaomi.com
 */

public class StartProcessFragment extends Fragment implements View.OnClickListener {
    private View mContentView;
    private Button mClick;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mContentView = inflater.inflate(R.layout.fragment_start_process, container, false);
        mClick = (Button) mContentView.findViewById(R.id.go_to);
        listenView();
        return mContentView;
    }

    private void listenView() {
        mClick.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.go_to:
                Intent intent = new Intent(getContext(), UiProcessActivity.class);
                startActivity(intent);
        }
    }
}
