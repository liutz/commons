package com.xiaomi.miadsdkdemo;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.miui.zeus.logger.MLog;
import com.xiaomi.miadsdkdemo.ui.SdkSampleBean;
import com.xiaomi.miadsdkdemo.util.AdViewHelper;
import com.xiaomi.miglobaladsdk.nativead.api.CustomAdManager;
import com.xiaomi.miglobaladsdk.nativead.api.ICustomAd;
import com.xiaomi.miglobaladsdk.nativead.api.LoadConfigBean;
import com.xiaomi.miglobaladsdk.report.AdReportHelper;

import static com.xiaomi.miglobaladsdk.bannerad.BannerAdSize.BANNER_300_250;

/**
 * Created by wangguoqiang on 19-1-7.
 */

public class CustomAdFragment extends Fragment {

    private static final String TAG = "CustomAdFragment";
    private SdkSampleBean sampleBean;
    private String mPositionId = "1.305.3.1";
    private Context mContext;
    private View mContentView;
    private FrameLayout nativeAdContainer;
    private ICustomAd mCustomAd;
    private CustomAdManager mCustomAdManager;

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = getActivity().getApplicationContext();
        mCustomAdManager = new CustomAdManager(mContext, mPositionId);
        String extraInfo = mCustomAdManager.getExtraInfo(mPositionId);
        if (!TextUtils.isEmpty(extraInfo)) {
            MLog.i(TAG, extraInfo);
        }
        mCustomAdManager.setNativeAdManagerListener(new CustomAdManager.CustomAdManagerListener() {
            @Override
            public void adLoaded() {
                addAdView();
                MLog.d(TAG, "adLoaded");
            }

            @Override
            public void adFailedToLoad(int code) {
                Toast.makeText(mContext, "onLoaderFailed errorCode:" + code, Toast.LENGTH_SHORT).show();
                MLog.d(TAG, "OnLoaderFailed errorCode: " + code);
            }

            @Override
            public void adImpression(ICustomAd customAd) {
                MLog.d(TAG, "adImpression");
            }

            @Override
            public void adClicked(ICustomAd customAd) {
                Toast.makeText(mContext, "adClicked nativeAd" + customAd.getAdTitle(), Toast.LENGTH_SHORT).show();
                MLog.d(TAG, "AdClicked nativeAd: " + customAd.getAdTitle());
            }

            @Override
            public void adDisliked(ICustomAd customAd, int dislikeCode) {
                customAd.unregisterView();
                mCustomAd = null;
                MLog.d(TAG, "AdDisliked nativeAd, dislikeCode: " + dislikeCode);
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        mContentView = layoutInflater.inflate(R.layout.fragment_customad_layout, container, false);
        nativeAdContainer = mContentView.findViewById(R.id.big_ad_container);
        sampleBean = SdkSampleBean.fromBundle(getArguments());
        ((TextView) mContentView.findViewById(R.id.description)).setText(sampleBean.getDescription());

        AdReportHelper.reportPV(mPositionId);
        mCustomAdManager.setLoadConfig(new LoadConfigBean.Builder()
                .setNativeAdOptionsAB(LoadConfigBean.NativeAdOptions.ADCHOICES_BOTTOM_LEFT)
                .setBannerAdParameter(BANNER_300_250)
                .build());
        mCustomAdManager.loadAd();
        return mContentView;
    }

    @Override
    public void onDestroy() {
        if (mCustomAd != null) {
            mCustomAd.unregisterView();
        }
        if (mCustomAdManager != null) {
            mCustomAdManager.destroyAd();
        }
        super.onDestroy();
    }

    private void addAdView() {
        if (mCustomAdManager != null) {
            mCustomAd = mCustomAdManager.getAd();
            if (mCustomAd == null) {
                return;
            }
            if (mCustomAd.isBannerAd()) {
                mCustomAd.showBannerView(nativeAdContainer);
                MLog.e(TAG, "showBannerView: " + mCustomAd.getAdTypeName());
                return;
            }
            //如果只要实现某个类型的广告，需要判断广告类型通过ad.getAdTypeName()
            MLog.d(TAG, "body: " + mCustomAd.getAdBody() + " ,title: " + mCustomAd.getAdTitle() + " ,mAdType: " + mCustomAd.getAdTypeName());
            View adView = AdViewHelper.createAdView(mContext, mCustomAd);
            nativeAdContainer.removeAllViews();
            nativeAdContainer.addView(adView);
            MLog.e(TAG, "adPackageName: " + mCustomAd.getAdPackageName());
        }
    }
}