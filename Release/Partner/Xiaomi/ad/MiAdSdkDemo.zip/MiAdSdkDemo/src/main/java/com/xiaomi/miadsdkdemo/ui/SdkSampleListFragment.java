package com.xiaomi.miadsdkdemo.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.miui.zeus.logger.MLog;
import com.xiaomi.miadsdkdemo.R;
import com.xiaomi.miglobaladsdk.Const;

import java.util.List;

/**
 * Created by xiezhilin on 17-4-14.
 */
public class SdkSampleListFragment extends ListFragment {
    private static final String TAG = "SdkSampleListFragment";

    private SdkSampleListAdapter mAdapter;
    private SdkSampleListFragmentItem mOrionDataSource;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeAdapter();
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.sample_list_fragment, container, false);
        final TextView versionCodeView = (TextView) view.findViewById(R.id.version_code);
        versionCodeView.setText("SDK Version " + Const.VERSION);
        return view;
    }

    private void initializeAdapter() {
        mAdapter = new SdkSampleListAdapter(getActivity());
        mOrionDataSource = new SdkSampleListFragmentItem(getActivity());

        final List<SdkSampleBean> ItemModel = mOrionDataSource.getDefaultItem();
        for (final SdkSampleBean model : ItemModel) {
            mAdapter.add(model);
        }
        setListAdapter(mAdapter);
    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id) {
        super.onListItemClick(listView, view, position, id);
        final SdkSampleBean itemModel = mAdapter.getItem(position);

        final FragmentTransaction fragmentTransaction =
                getActivity().getSupportFragmentManager().beginTransaction();

        final Class<? extends Fragment> fragmentClass = itemModel.getFragmentClass();
        final Fragment fragment;

        if (fragmentClass == null) {
            Toast.makeText(getActivity(), "This function unusable", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            fragment = fragmentClass.newInstance();
        } catch (java.lang.InstantiationException e) {
            MLog.e(TAG, "Error creating fragment for class " + fragmentClass, e);
            return;
        } catch (IllegalAccessException e) {
            MLog.e(TAG, "Error creating fragment for class " + fragmentClass, e);
            return;
        } catch (Exception e) {
            MLog.e(TAG, "Error creating fragment for class " + fragmentClass, e);
            return;
        }

        fragment.setArguments(itemModel.toBundle());

        fragmentTransaction
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onDestroy() {
        mAdapter = null;
        mOrionDataSource = null;
        super.onDestroy();
    }

}

