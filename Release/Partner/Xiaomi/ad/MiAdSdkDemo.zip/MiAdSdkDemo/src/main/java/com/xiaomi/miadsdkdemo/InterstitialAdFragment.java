package com.xiaomi.miadsdkdemo;

import com.miui.zeus.logger.MLog;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.xiaomi.miglobaladsdk.interstitialad.InterstitialAdCallback;
import com.xiaomi.miglobaladsdk.interstitialad.InterstitialAdManager;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;

/**
 * @author luoyanfeng@xiaomi.com
 */


public class InterstitialAdFragment extends Fragment {

    private static final String TAG = "InterstitialAdFragment";

    private TextView mTipView;

    private InterstitialAdManager mInterstitialAdManager;

    private boolean shouldShowAd;
    private boolean shouldLoadAd;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_interstitial, container, false);
        initViews(view);
        init();
        return view;
    }

    private void initViews(View rootView) {
        mTipView = (TextView) rootView.findViewById(R.id.tip);

        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (shouldLoadAd) {
                    mTipView.setText(R.string.interstitial_tip_loading);
                    mInterstitialAdManager.loadAd();
                }
            }
        });
    }

    private void init() {
        mInterstitialAdManager = new InterstitialAdManager(getContext(), "1.305.17.2");
        mInterstitialAdManager.setInterstitialAdCallback(new InterstitialAdCallback() {
            @Override
            public void onAdLoaded() {
                Activity activity = getActivity();
                if (activity == null || activity.isFinishing()) {
                    return;
                }
                shouldLoadAd = false;
                Log.d(TAG, "onAdLoaded " + mInterstitialAdManager.getAdType());
                mTipView.setText(
                        String.format(getString(R.string.interstitial_tip_loaded), mInterstitialAdManager.getAdType()));
            }

            @Override
            public void onAdLoadedFailed(int errorCode) {
                Activity activity = getActivity();
                if (activity == null || activity.isFinishing()) {
                    return;
                }
                shouldLoadAd = true;
                Log.d(TAG, "onAdLoadedFailed " + errorCode);
                mTipView.setText(String.format(getString(R.string.interstitial_tip_failed), errorCode));
            }

            @Override
            public void onAdDisplayed() {
                Log.d(TAG, "onAdDisplayed");
            }

            @Override
            public void onAdDismissed() {
                Log.d(TAG, "onAdDismissed");
                shouldLoadAd = true;
                mTipView.setText(R.string.interstitial_tip_touch_to_load);
            }

            @Override
            public void onAdClicked() {
                Log.d(TAG, "onAdClicked");
            }

            @Override
            public void adDisliked(INativeAd nativeAd, int dislikeCode) {
                MLog.d(TAG, "AdDisliked nativeAd");
            }
        });
        mInterstitialAdManager.loadAd();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (shouldShowAd) {
            shouldShowAd = false;
            if (mInterstitialAdManager.isReady()) {
                mInterstitialAdManager.showAd();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        shouldShowAd = true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mInterstitialAdManager.destroyAd();
    }
}
