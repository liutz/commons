package com.xiaomi.miadsdkdemo.util;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.AdIconView;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAdBase;
import com.facebook.ads.NativeAdLayout;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import com.miui.zeus.logger.MLog;
import com.my.target.nativeads.factories.NativeViewsFactory;
import com.xiaomi.miadsdkdemo.R;
import com.xiaomi.miglobaladsdk.Const;
import com.xiaomi.miglobaladsdk.nativead.api.INativeAd;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xiezhilin on 17-4-17.
 */
public class AdViewHelper {
    private static final String TAG = "AdViewHelper";
    final protected Context mContext;

    public static View createAdView(Context context, INativeAd ad) {
        return new AdViewHelper(context).createAdView(ad);
    }

    public AdViewHelper(Context context) {
        mContext = context;
    }

    /**
     * NOTE: 接入Admob广告需要注意：如果广告是Admob的广告需要用Admob提供的根布局做广告的布局
     */
    private View createAdView(INativeAd ad) {
        if (ad == null) {
            return null;
        }

        View adView = null;
        if (ad.isNativeAd()) {
            if (isAdMobAd(ad)) {
                adView = createAdMobView(ad);
            } else {
                adView = createStandardAdView(ad);
            }
        } else {
            if (ad.getAdObject() instanceof View) {
                adView = (View) ad.getAdObject();
            }
        }
        return adView;
    }

    private View createStandardAdView(INativeAd ad) {
        if (ad == null) {
            return null;
        }
        View adView = View.inflate(mContext, R.layout.native_ad_layout, null);
        String iconUrl = ad.getAdIconUrl();
        ImageView iconImageView = adView.findViewById(R.id.native_icon_image);
        if (iconUrl != null) {
            VolleyUtil.loadImage(iconImageView, iconUrl);
        }

        // 根据需要去获取相应的控件，demo只是一个示例
        LinearLayout mainContainer = adView.findViewById(R.id.ll_main_parent);
        MediaView mediaViewMain = adView.findViewById(R.id.native_main_media);
        AdIconView adIconView = adView.findViewById(R.id.native_ad_icon);
        ImageView imageViewMain = adView.findViewById(R.id.native_main_image);
        LinearLayout adChoicesContainer = adView.findViewById(R.id.ad_choices_container);
        // 获取大卡的背景图片的url
        String mainImageUrl = ad.getAdCoverImageUrl();
        // 目前demo在测试的过程中遇到一个问题，在使用fb的MediaView的过程中，如果在xml中将MediaView设置为gone
        // 在代码中调用mediaViewMain.setVisibility(View.VISIBLE)，MediaView里面是video广告的情况可能造成
        // video不显示，所以需要在MediaView外面包一层来控制显示与否
        mainContainer.setVisibility(View.VISIBLE);
        Object adObject = ad.getAdObject();
        NativeAdLayout nativeAdLayout = null;
        if (ad.getAdTypeName().contains(Const.KEY_FB) && adObject instanceof NativeAdBase) {
            nativeAdLayout = new NativeAdLayout(mContext);
            nativeAdLayout.addView(adView);
            AdOptionsView adOptionsView = new AdOptionsView(mContext, (NativeAdBase) adObject, nativeAdLayout);
            adChoicesContainer.addView(adOptionsView, 0);
            imageViewMain.setVisibility(View.GONE);
            iconImageView.setVisibility(View.GONE);

            adIconView.setVisibility(View.VISIBLE);
        } else if (ad.getAdTypeName().contains(Const.KEY_MT)) {
            imageViewMain.setVisibility(View.GONE);
            mediaViewMain.setVisibility(View.GONE);
            adIconView.setVisibility(View.GONE);
            iconImageView.setVisibility(View.VISIBLE);
            // getMediaAdView 参数必须使用当前activity的context
            // mytarget 的MediaAdView能自动下载播放视频和图片,也可以使用ImageView自己填充图片
            mainContainer.addView(NativeViewsFactory.getMediaAdView(mContext));
        } else {
            iconImageView.setVisibility(View.VISIBLE);
            adIconView.setVisibility(View.GONE);
            mediaViewMain.setVisibility(View.GONE);
            if (mainImageUrl != null) {
                VolleyUtil.loadImage(imageViewMain, mainImageUrl);
            }
        }

        MLog.e(TAG, mainImageUrl != null ? mainImageUrl : "mainImageUrl is null");

        TextView titleTextView = adView.findViewById(R.id.native_title);
        Button bigButton = adView.findViewById(R.id.native_cta);
        TextView bodyTextView = adView.findViewById(R.id.native_text);

        titleTextView.setText(ad.getAdTitle());
        bigButton.setText(ad.getAdCallToAction());

        bodyTextView.setText(ad.getAdBody());
        if (ad.getAdTypeName().contains(Const.KEY_FB)
                || ad.getAdTypeName().contains(Const.KEY_MI)
                || ad.getAdTypeName().contains(Const.KEY_MT)) {
            // 根据需求添加相应的click view
            List<View> clickableViews = new ArrayList<>();
            clickableViews.add(iconImageView);
            clickableViews.add(titleTextView);
            clickableViews.add(mediaViewMain);
            clickableViews.add(imageViewMain);
            clickableViews.add(bigButton);
            clickableViews.add(adIconView);
            ad.registerViewForInteraction(adView, clickableViews);
        } else {
            ad.registerViewForInteraction(adView);
        }
        if (ad.getAdTypeName().contains(Const.KEY_FB)) {
            return nativeAdLayout;
        }
        return adView;
    }

    private boolean isAdMobAd(INativeAd ad) {
        return ad != null && ad.getAdObject() instanceof UnifiedNativeAd;
    }

    private View createAdMobView(INativeAd ad) {
        String adTypeName = ad.getAdTypeName();
        if (!adTypeName.startsWith(Const.KEY_AB)) {
            return null;
        }
        UnifiedNativeAdView adView = (UnifiedNativeAdView) View
                .inflate(mContext, R.layout.admob_native_ad_layout, null);
        setValueToView(adView, ad);
        setAdViewToAdmob(adView, (UnifiedNativeAd) ad.getAdObject());
        ad.registerViewForInteraction(adView);
        return adView;
    }

    private void setValueToView(UnifiedNativeAdView adView, INativeAd ad) {
        TextView body = adView.findViewById(R.id.unified_body);
        TextView title = adView.findViewById(R.id.unified_title);
        ImageView icon = adView.findViewById(R.id.unified_icon);
        Button action = adView.findViewById(R.id.unified_action_btn);
        body.setText(ad.getAdBody());
        title.setText(ad.getAdTitle());
        String iconUrl = ad.getAdIconUrl();
        if (iconUrl != null) {
            VolleyUtil.loadImage(icon, iconUrl);
            icon.setVisibility(View.VISIBLE);
        } else {
            icon.setVisibility(View.GONE);
        }
        action.setText(ad.getAdCallToAction());
    }

    private void setAdViewToAdmob(UnifiedNativeAdView adView, UnifiedNativeAd unifiedNativeAd) {
        adView.setBodyView(adView.findViewById(R.id.unified_body));
        adView.setHeadlineView(adView.findViewById(R.id.unified_title));
        adView.setIconView(adView.findViewById(R.id.unified_icon));
        adView.setCallToActionView(adView.findViewById(R.id.unified_action_btn));
        adView.setMediaView((com.google.android.gms.ads.formats.MediaView) adView.findViewById(R.id.unified_media_view));
        adView.setNativeAd(unifiedNativeAd);
    }
}
