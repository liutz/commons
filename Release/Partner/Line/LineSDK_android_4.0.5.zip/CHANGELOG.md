# Change Log

All notable changes to the LINE SDK will be documented in this file.

## 4.0.5 - 2017/06/02

* Fixed an issue where a runtime error occurs upon calling startActivityForActivity with a login intent when using appcompat version 25.0.0 or higher.

## 4.0.4 - 2017/04/25

* Made a minor change to the SDK's authentication logic to fix a problem where onActivityResult does not get executed during app-to-app login.
* Fixed a known issue in 4.0.2 where onActivityResult returns a result of "CANCEL" on the first time that a user logs into an application using app-to-app login. 

## 4.0.2 - 2017/04/10

* Fixed an issue where browser login fails with an INTERNAL_ERROR on Android 4.x devices.

### Known Issues

* On 4.x devices, onActivityResult will return a result of "CANCEL" on the first time that a user logs into an application using app-to-app login. The user will be able to successfully log in from their second attempt. This issue is caused by a problem in the LINE Application and will be resolved in a future update.
* If the "Don't Keep Activities" developer option is set to ON, you may encounter unexpected issues during the login process. This is a known issue and will be fixed in a future update.

## 4.0.0 - 2017/01/24

* Initial Release
